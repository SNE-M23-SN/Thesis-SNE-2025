package com.diploma.inno;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DiplomaApplicationTests {

	@Test
	void contextLoads() {
	}

}
